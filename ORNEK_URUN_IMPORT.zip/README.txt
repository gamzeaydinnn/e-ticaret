📦 ÖRNEK ZIP IMPORT PAKETİ
================================

Bu klasörü ZIP olarak sıkıştırıp Admin Panelden yükleyebilirsiniz!

İÇERİK:
-------
✅ data.csv - 6 örnek ürün bilgileri
✅ Görsel dosyaları (jpg formatında)

NASIL KULLANILIR:
-----------------
1. Bu klasörü (ornek_zip_import) sağ tıklayın
2. "Sıkıştırılmış klasöre gönder" veya "Send to Compressed folder" seçin
3. Oluşan .zip dosyasını Admin Panelden yükleyin:
   - Admin Panel > Ürün Yönetimi
   - "Excel'den İçe Aktar" butonuna tıklayın
   - "ZIP (Önerilen)" seçeneğini seçin
   - ZIP dosyasını yükleyin

NOT:
----
- CSV'deki ImageUrl sütununda sadece dosya adı var (örn: kasar-peyniri.jpg)
- Sistem otomatik olarak ZIP içindeki görselleri bulup yükler
- Görseller örnek olarak basit renkli kareler şeklinde oluşturuldu
- Gerçek görsellerinizi aynı dosya adlarıyla değiştirebilirsiniz

KATEGORİ ID'LERİ:
-----------------
3 = Et & Tavuk
4 = Süt Ürünleri
5 = Meyve & Sebze
9 = Temel Gıda

DESTEK:
-------
Sorularınız için: admin@eticaret.com
